import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms'; 
import { HttpClientModule } from '@angular/common/http'; 
import { AppComponent } from './app.component';
import { ProfilelistComponent } from './profile/profilelist/profilelist.component';
import { AddFriendCompComponent } from './addfriend/add-friend-comp/add-friend-comp.component';
import { SmsComponent } from './sms/sms.component';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import { LoginpageComponent } from './loginpage/loginpage.component';
import { loginService } from './loginpage/loginservice';
import { ForgotpasswordComponent } from './forgotpassword/forgotpassword.component';
import { RouterModule, Routes } from "@angular/router";
import { NextPageComponent } from './next-page/next-page.component';
import { ChangepasswordComponent } from './changepassword/changepassword.component';	
import { PrivacyComponent } from './privacy/privacy.component';
import { UserProfile;Component } from './user-profile;/user-profile;.component';

 	 
 
@NgModule({
  declarations: [
    AppComponent,
    ProfilelistComponent,
    AddFriendCompComponent,
    SmsComponent,
    FooterComponent,
    HeaderComponent,
    LoginpageComponent,
    ForgotpasswordComponent,
    NextPageComponent,
    // ChangepasswordComponent,
    PrivacyComponent,
    UserProfile;Component
    
    
  ],
  imports: [
    FormsModule,
    HttpClientModule,
    BrowserModule,
      RouterModule.forRoot([
      { path :'HomePage',component: NextPageComponent },
      { path : '' , redirectTo:'/HomePage' , pathMatch:'full' }, 
      { path :'forgotpwd',component: ForgotpasswordComponent }
    ])
  
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
