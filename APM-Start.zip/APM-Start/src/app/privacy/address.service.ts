import { Injectable } from "@angular/core";

import { HttpClient, HttpErrorResponse, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs/Observable";
import "rxjs/add/observable/throw";
import "rxjs/add/operator/do";
import "rxjs/add/operator/catch";
import { Address } from "./address";


const httpOptions ={
headers :new HttpHeaders({'Content-Type':'application/json'})
};
@Injectable()
export class addrService{
private postaddUrl='http://localhost:8083/profileCreation/Profilesettings';
private address:Address[];



constructor(private _http:HttpClient){

} 
 
postAdd(addr:Address):Observable<Address>
{
alert();
return this._http.post<Address>(this.postaddUrl,addr,{})
} 
 
/* postuser(userp:UserProfile):Observable<UserProfile>
{


return this._http.post<UserProfile>(this.postUser,userp,{})
} 

changePaswd(password:ChangePassword):Observable<ChangePassword>
{
return this._http.post<ChangePassword>(this.changepsswd,password,{})
} 


getLogin(login:Login):Observable<Login>{
    this.getLoginUrl=this.getLoginUrl+'/'+'login.email'+'/'+'login.password'
    return this._http.post<Login>(this.getLoginUrl,login,{})

} */
}
