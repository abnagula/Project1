import { UserProfile } from "../loginpage/userprofile";

export class Address{

     addressId:number;
	doorNumber:string;
	  street:string;
	 locality:string;
	city:string;
	state:string;
	UserProfile:UserProfile;
}