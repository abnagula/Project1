import { Component, OnInit } from '@angular/core';
import { Login } from '../loginpage/login';
import{loginService} from '../loginpage/loginservice';
@Component({
  selector: 'pm-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  login:Login=new Login();
  logs:Login=new Login();
  logins:Login[]=[];
  flag:boolean=false;
 
  constructor(private lgnservice:loginService) { }

  ngOnInit() {
   
  }

  Home():void{

   /* this.getLogin()
   if(login!=null){
     console.log("hai")
   } */
  }

  getLogin():void{
    console.log(this.login.email)
    /* if(this.lgnservice.getLogin(this.login)==null){
alert("Invalid login")
    } */
    this.lgnservice.getLogin(this.login).subscribe(logs=>{this.logs=this.login;
      console.log(logs)
    if(logs==null){alert("Invalid")}
else{alert("GIVE ROUTER LINK TO MOVE FURTHER")}  
  });
  
}
}
