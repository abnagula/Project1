import { Component } from '@angular/core';
import {smsService} from './sms/sms.service';

import{loginService} from './loginpage/loginservice';
import { frgtService } from './forgotpassword/forgotpassword.service';

@Component({
  selector: 'app-root',

  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers:[smsService,loginService,frgtService]
})
export class AppComponent {
 
}
