import { Component, OnInit } from '@angular/core';
import { Sms } from './sms';
import { smsService } from './sms.service';

@Component({
  selector: 'pm-sms',
  templateUrl: './sms.component.html',
  styleUrls: ['./sms.component.css']
})
export class SmsComponent implements OnInit {

  button:string='send'
  flag:boolean=false
  sms:Sms=new Sms();
  constructor(private smsservice:smsService) { }

  onSubmit():void{
    if(this.flag){
      alert('unable to send sms')
    }
    else{
      this.sendSms()
    }
  }

  sendSms():void{
    this.button="Send"
    console.log(JSON.stringify(this.sms))
    this.smsservice.postSms(this.sms).subscribe(sms=>this.sms)
  }
  ngOnInit() {
    this.sendSms()
      }

}
