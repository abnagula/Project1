export class Email{
    fromAddress : string;
	toAddress : string;
    subject : string;
    messageBody :string;
	date : Date;
}
