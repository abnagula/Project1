package com.capgemini.capbook.dao;

import javax.transaction.Transactional;
import javax.websocket.server.PathParam;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.capgemini.capbook.bean.Address;

@Repository("addressDao")
@Transactional
public interface IAddressdao extends JpaRepository<Address, Integer>{
	
/*  @Query("select email from UserProfile where email:email") 	
   public String findByEmail(@PathParam("email") String email);
  
 @Query("insert into Address(user) values(user:user)")
 public Integer saveUserId(@PathParam("user") Integer userId);*/
	
}
