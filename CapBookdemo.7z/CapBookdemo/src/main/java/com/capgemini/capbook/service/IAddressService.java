package com.capgemini.capbook.service;

import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.web.bind.annotation.PathVariable;

import com.capgemini.capbook.bean.Address;



public interface IAddressService {

	public List<Address> saveDetails(Address addr);

	public List<Address> getAllDetails();
	
//	public Integer saveUserId(@PathParam("user") Integer userId);
	
	
}
