package com.capgemini.capbook.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capbook.bean.Login;
import com.capgemini.capbook.service.ICapBookService;

@RestController
@RequestMapping("/forgetPwd")
@CrossOrigin("*")
public class PasswordController {
	@Autowired
	private ICapBookService friendservice;

	@GetMapping(value="/passwd/{email}")
		 ResponseEntity getPassword(@PathVariable("email") String mail){
		 String mailId=mail;
		 
			String password= friendservice.getPassword(mail);
			if(password.isEmpty())
			{
				return new ResponseEntity("Sorry! unable to get password", 
						HttpStatus.NOT_FOUND); 
			}
			
			return new ResponseEntity(password, HttpStatus.OK);
		}

	@PostMapping(value="/EmailNPwd/{email}/{password}")
	ResponseEntity<List<Login>> getPassword(@PathVariable("email") String email,@PathVariable("password") String password){
		List<Login> lg= friendservice.findByUsernameAndPassword(email, password);
		if(lg.isEmpty())
		{
			return new ResponseEntity("Sorry! unable to add friends",
					HttpStatus.NOT_FOUND); 
		}
		
		return new ResponseEntity<List<Login>>(lg, HttpStatus.OK);
	}
	
	
	
}
