package com.capgemini.capbook.dao;

import javax.transaction.Transactional;
import javax.websocket.server.PathParam;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.capbook.bean.ChangePassword;

@Repository("psswdDao")
@Transactional

public interface IPasswdDao extends JpaRepository<ChangePassword, String>{
@Query("select l.password from Login l where l.email=:email")
public String getPassword(@Param("email") String mail);


}
