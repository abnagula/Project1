package com.capgemini.capbook.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.capgemini.capbook.bean.Address;
import com.capgemini.capbook.dao.IAddressdao;

@Service("addressService")
public class AddressServiceImpl implements IAddressService {

	@Autowired
	private IAddressdao addressDao;
	@Override
	public List<Address> saveDetails(Address addr)  {
       addressDao.save(addr);
       return addressDao.findAll();
	}

	@Override
	public List<Address> getAllDetails() {
		
		return addressDao.findAll();
	}

	/*@Override
	public Integer saveUserId(Integer userId) {
		
		return addressDao.saveUserId(userId);
	}*/

}
